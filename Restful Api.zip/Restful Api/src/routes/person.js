let express = require ('express')
let router = express.Router()

// QueryString => query property on the request object
//localhost:3000/person?name=ashwini&age=20
router.get('/person',function(req,res){
    if(req.query.name){
        res.send(`You have requested a person ${req.query.name}`)
    }
    else{
        res.send('You have requested a person')
    }
})
//Params property on the request object
//localhost:3000/person/ashwini
router.get('/person/:name',function(req,res){
    res.send(`You have requested a person ${req.params.name}`)
})

router.get('/error' , function(req,res){
    throw new Error('This is a forced Error')
})
module.exports = router
